import { useState } from "react";
import {
	NativeScrollEvent,
	NativeSyntheticEvent,
	ScrollView,
	StyleSheet,
} from "react-native";
import { AnimatedFAB, Appbar } from "react-native-paper";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { Todo } from "@interfaces/Todo";
import TodoItem from "@components/TodoItem";
import { StatusBar } from "expo-status-bar";
import { COLORS } from "constants/Colors";

export default function App() {
	const [todos, setTodos] = useState<Todo[]>([]);
	const [isExtended, setIsExtended] = useState(false);
	const [idCount, setIdCount] = useState(0);

	function handleScroll(
		nativeEvent: NativeSyntheticEvent<NativeScrollEvent>
	) {
		const currentScrollPosition =
			Math.floor(nativeEvent.nativeEvent.contentOffset.y) ?? 0;
		setIsExtended(currentScrollPosition <= 0);
	}

	function handleTodoAdd() {
		setIdCount(idCount + 1);

		const newTodo: Todo = {
			title: "",
			isCompleted: false,
			id: idCount.toString(),
		};

		setTodos([...todos, newTodo]);
	}

	function handleTodoChange(updatedTodo: Todo) {
		const updatedTodos = todos.map((todo) =>
			todo.id === updatedTodo.id ? updatedTodo : todo
		);
		setTodos(updatedTodos);
	}

	function handleTodoDelete(id: string) {
		const updatedTodos = todos.filter((todo) => todo.id !== id);
		setTodos(updatedTodos);
	}

	return (
		<SafeAreaProvider>
			<StatusBar style="auto" />

			<Appbar.Header
				elevated
				style={{ backgroundColor: COLORS.desertSand }}
			>
				<Appbar.Content
					title="Sparky To Do"
					titleStyle={{ fontWeight: "bold" }}
				/>
			</Appbar.Header>

			<SafeAreaView style={styles.container}>
				<ScrollView
					contentContainerStyle={{ gap: 20 }}
					onScroll={handleScroll}
				>
					{todos.map((todo) => (
						<TodoItem
							key={todo.id}
							todo={todo}
							onTodoChange={(updatedTodo) =>
								handleTodoChange(updatedTodo)
							}
							onTodoDelete={(id) => handleTodoDelete(id)}
						/>
					))}
				</ScrollView>

				<AnimatedFAB
					icon="plus"
					label={"Agregar Todo"}
					extended={isExtended}
					style={{
						position: "absolute",
						bottom: 16,
						right: 16,
						backgroundColor: COLORS.pearl,
					}}
					onPress={handleTodoAdd}
				/>
			</SafeAreaView>
		</SafeAreaProvider>
	);
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: "#fff",
		fontFamily: "Roboto",
		padding: 10,
		gap: 20,
	},
});
