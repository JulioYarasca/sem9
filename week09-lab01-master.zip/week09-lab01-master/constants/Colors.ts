export const COLORS = {
	desertSand: "#E4BE9E",
	honeyDew: "#D0E1D4",
	pearl: "#D9D2B6"
};
