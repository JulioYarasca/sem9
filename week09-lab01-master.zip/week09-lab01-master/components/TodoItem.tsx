import { useEffect, useRef, useState } from "react";
import { IconButton, MD3Colors } from "react-native-paper";
import { TextInput, View } from "react-native";
import { Todo } from "@interfaces/Todo";
import { COLORS } from "constants/Colors";

interface TodoItemProps {
	todo: Todo;
	onTodoChange: (updatedTodo: Todo) => void;
	onTodoDelete: (id: string) => void;
}

export default function TodoItem(props: TodoItemProps) {
	const [title, setTitle] = useState(props.todo.title);
	const [isCompleted, setIsCompleted] = useState(props.todo.isCompleted);
	const textInputRef = useRef<TextInput>(null);

	useEffect(() => {
		if (textInputRef.current) {
			textInputRef.current.focus();
		}
	}, []);

	function handleChangeText(text: string) {
		setTitle(text);
		props.onTodoChange({ ...props.todo, title: text });
	}

	function handleToggleComplete() {
		const newCompletionStatus = !isCompleted;
		setIsCompleted(newCompletionStatus);
		props.onTodoChange({ ...props.todo, isCompleted: newCompletionStatus });
	}

	return (
		<View
			style={{
				backgroundColor: COLORS.honeyDew,
				borderRadius: 20,
				flexDirection: "row",
				alignItems: "center",
				padding: 10,
			}}
		>
			<IconButton
				icon={isCompleted ? "check" : "close"}
				onPress={handleToggleComplete}
				iconColor={
					isCompleted ? MD3Colors.primary50 : MD3Colors.error50
				}
			/>
			<TextInput
				value={title}
				style={{ flex: 1, marginLeft: 8, fontSize: 17 }}
				ref={textInputRef}
				onChangeText={handleChangeText}
				multiline
			/>
			<IconButton
				icon="trash-can"
				onPress={() => props.onTodoDelete(props.todo.id)}
			/>
		</View>
	);
}
